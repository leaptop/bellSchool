# SoapUI Maven plugin

*This is a submodule of [SoapUI project](../)*

See our [website](http://www.soapui.org/Test-Automation/maven-2x.html) for documentation on how to use the plugin.
