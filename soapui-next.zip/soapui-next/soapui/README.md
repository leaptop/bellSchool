# SoapUI core module

*This is a submodule of [SoapUI project](../)*

This is the core module for creating the soapui.jar and installers.