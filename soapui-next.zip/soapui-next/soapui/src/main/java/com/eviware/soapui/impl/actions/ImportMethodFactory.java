package com.eviware.soapui.impl.actions;

public interface ImportMethodFactory {
    ImportMethod createNewImportMethod();
}
