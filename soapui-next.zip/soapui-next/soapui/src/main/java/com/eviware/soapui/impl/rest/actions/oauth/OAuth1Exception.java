package com.eviware.soapui.impl.rest.actions.oauth;

public class OAuth1Exception extends Exception {
    public OAuth1Exception(Throwable e) {
        super(e);
    }
}
