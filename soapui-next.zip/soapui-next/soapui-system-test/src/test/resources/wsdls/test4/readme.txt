This setup uses only relative imports and also includes testservice2.xsd into the 
wsdls types (so it gets included twice)